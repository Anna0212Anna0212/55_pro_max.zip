﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSA05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static string file_name = "user.txt";

        private void Form1_Load(object sender, EventArgs e)
        {
            File.WriteAllText(file_name, "");
            butt_lab_User.Visible = panel1.Visible = false;
            lab_User.Text = "";
        }

        private void che_user()
        {
            if(lab_User.Text != "")
            {
                butt_lab_User.Visible = panel1.Visible = true;
            }
            else
            {
                butt_lab_User.Visible = panel1.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (text_user.Text == "" || text_pass1.Text == "" || text_pass2.Text == "")
            {
                lab11.Text = "輸入資料";
                return;
            }
            if (!Regex.IsMatch(text_pass1.Text, @"[^0-9a-zA-Z]") || text_pass1.Text.Length < 8 || !Regex.IsMatch(text_pass1.Text, @"[0-9a-zA-Z]"))
            {
                lab11.Text = "密碼強度不足";
                return;
            }
            if (text_pass1.Text != text_pass2.Text)
            {
                lab11.Text = "確認密碼錯誤";
                return;
            }

            string sha = BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(text_pass1.Text))).Replace("-", "");

            string[] file_line = File.ReadAllLines(file_name);
            foreach (string line in file_line)
            {
                if (line.Split('|')[0] == text_user.Text)
                {
                    lab11.Text = "帳號已註冊";
                    return;
                }
            }

            File.AppendAllText(file_name, text_user.Text + "|" + sha + "\n");
            lab_User.Text = text_user.Text;
            text_user.Text = text_pass1.Text = text_pass2.Text = null;
            che_user();
            lab11.Text = "";
            MessageBox.Show("註冊成功");
        }

        private void butt2_Click(object sender, EventArgs e)  //登陸
        {
            if (text_down1.Text == "" || text_down2.Text == "")
            {
                lab1.Text = "輸入資料";
                return;
            }

            string sha = BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(text_down2.Text))).Replace("-", "");

            List<string> file_line = File.ReadAllLines(file_name).ToList();
            foreach (string line in file_line)
            {
                if (line == $"{text_down1.Text}|{sha}")
                {
                    lab_User.Text = text_down1.Text;
                    label1.Text = "";
                    text_down1.Text = text_down2.Text = text_down3.Text = text_down4.Text = null;
                    che_user();
                    lab1.Text = "";
                    MessageBox.Show("登陸成功");
                    return;
                }
            }
            lab1.Text = "為尋找到相同資料";
        }

        private void butt_lab_User_Click(object sender, EventArgs e)
        {
            lab_User.Text = "";
            che_user() ;
        }

        private void butt1_Click(object sender, EventArgs e)
        {
            if(text_down1.Text == "" || text_down2.Text == "" || text_down4.Text == "")
            {
                lab2.Text = "輸入資料";
                return ;
            }
            if (text_down2.Text != text_down4.Text)
            {
                lab2.Text = "密碼確認失敗";
                return;
            }

            string sha = BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(text_down2.Text))).Replace("-", "");

            List<string> file_line = File.ReadAllLines(file_name).ToList();
            foreach (string line in file_line)
            {
                if (line == $"{text_down1.Text}|{sha}")
                {
                    file_line.Remove(line);
                    File.WriteAllText(file_name,"");
                    foreach (string line2 in file_line)
                    {
                        File.AppendAllText(file_name,line2);
                    }

                    lab_User.Text = "";
                    lab2.Text = "";
                    text_down1.Text = text_down2.Text = text_down3.Text = text_down4.Text = null;
                    che_user();
                    MessageBox.Show("註銷成功");
                    return;
                }
            }

            lab2.Text = "未尋找到相同資料";
            text_down1.Text = text_down2.Text = text_down3.Text = text_down4.Text = null;
            che_user();
        }

        private void butt3_Click(object sender, EventArgs e)
        {
            if (text_down1.Text == "" || text_down2.Text == "" || text_down4.Text == "" || text_down3.Text == "")
            {
                lab2.Text = "輸入資料";
                return;
            }
            if (text_down3.Text != text_down4.Text)
            {
                lab2.Text = "密碼確認失敗";
                return;
            }

            string sha = BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(text_down2.Text))).Replace("-", "");
            string sha2 = BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(text_down3.Text))).Replace("-", "");

            List<string> file_line = File.ReadAllLines(file_name).ToList();
            foreach (string line in file_line)
            {
                if (line == $"{text_down1.Text}|{sha}")
                {
                    file_line.Remove(line);
                    file_line.Add($"{text_down1.Text}|{sha2}");
                    File.WriteAllText(file_name, "");
                    foreach (string line2 in file_line)
                    {
                        File.AppendAllText(file_name, line2);
                    }

                    lab2.Text = "";
                    text_down1.Text = text_down2.Text = text_down3.Text = text_down4.Text = null;
                    che_user();
                    MessageBox.Show("密碼更改成功");
                    return;
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            text_pass1.PasswordChar = text_pass2.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            text_down2.PasswordChar = text_down3.PasswordChar = text_down4.PasswordChar = checkBox2.Checked ? '\0' : '*';
        }
    }
}
