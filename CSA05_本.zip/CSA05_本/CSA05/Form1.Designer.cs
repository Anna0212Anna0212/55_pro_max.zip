﻿namespace CSA05
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.text_pass1 = new System.Windows.Forms.TextBox();
            this.text_user = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.butt_up = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.text_down1 = new System.Windows.Forms.TextBox();
            this.text_down2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.butt3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.butt2 = new System.Windows.Forms.Button();
            this.lab_User = new System.Windows.Forms.Label();
            this.butt_lab_User = new System.Windows.Forms.Button();
            this.text_pass2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.text_down3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.text_down4 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.butt1 = new System.Windows.Forms.Button();
            this.lab11 = new System.Windows.Forms.Label();
            this.lab2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lab1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(682, 523);
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lab11);
            this.tabPage1.Controls.Add(this.text_pass2);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.checkBox1);
            this.tabPage1.Controls.Add(this.text_pass1);
            this.tabPage1.Controls.Add(this.text_user);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.butt_up);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(674, 497);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "註冊";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(441, 292);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 16);
            this.checkBox1.TabIndex = 18;
            this.checkBox1.Text = "查看密碼";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // text_pass1
            // 
            this.text_pass1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.text_pass1.Location = new System.Drawing.Point(246, 204);
            this.text_pass1.Name = "text_pass1";
            this.text_pass1.PasswordChar = '*';
            this.text_pass1.Size = new System.Drawing.Size(236, 22);
            this.text_pass1.TabIndex = 13;
            // 
            // text_user
            // 
            this.text_user.Location = new System.Drawing.Point(246, 153);
            this.text_user.Name = "text_user";
            this.text_user.Size = new System.Drawing.Size(236, 22);
            this.text_user.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(174, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "密碼";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(174, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "帳號";
            // 
            // butt_up
            // 
            this.butt_up.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.butt_up.Location = new System.Drawing.Point(299, 332);
            this.butt_up.Name = "butt_up";
            this.butt_up.Size = new System.Drawing.Size(96, 57);
            this.butt_up.TabIndex = 8;
            this.butt_up.Text = "註冊";
            this.butt_up.UseVisualStyleBackColor = true;
            this.butt_up.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(284, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 7;
            this.label1.Text = "帳號註冊";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lab1);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Controls.Add(this.lab_User);
            this.tabPage2.Controls.Add(this.butt_lab_User);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.butt2);
            this.tabPage2.Controls.Add(this.checkBox2);
            this.tabPage2.Controls.Add(this.text_down1);
            this.tabPage2.Controls.Add(this.text_down2);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(674, 497);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "登陸";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(435, 207);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(72, 16);
            this.checkBox2.TabIndex = 19;
            this.checkBox2.Text = "查看密碼";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // text_down1
            // 
            this.text_down1.Location = new System.Drawing.Point(233, 123);
            this.text_down1.Name = "text_down1";
            this.text_down1.Size = new System.Drawing.Size(236, 22);
            this.text_down1.TabIndex = 13;
            // 
            // text_down2
            // 
            this.text_down2.Location = new System.Drawing.Point(233, 179);
            this.text_down2.Name = "text_down2";
            this.text_down2.PasswordChar = '*';
            this.text_down2.Size = new System.Drawing.Size(236, 22);
            this.text_down2.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(161, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "帳號";
            // 
            // butt3
            // 
            this.butt3.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.butt3.Location = new System.Drawing.Point(256, 114);
            this.butt3.Name = "butt3";
            this.butt3.Size = new System.Drawing.Size(96, 57);
            this.butt3.TabIndex = 9;
            this.butt3.Text = "更改密碼";
            this.butt3.UseVisualStyleBackColor = true;
            this.butt3.Click += new System.EventHandler(this.butt3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(271, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 27);
            this.label6.TabIndex = 7;
            this.label6.Text = "帳號登陸";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(161, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "密碼";
            // 
            // butt2
            // 
            this.butt2.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.butt2.Location = new System.Drawing.Point(295, 237);
            this.butt2.Name = "butt2";
            this.butt2.Size = new System.Drawing.Size(96, 57);
            this.butt2.TabIndex = 20;
            this.butt2.Text = "登陸";
            this.butt2.UseVisualStyleBackColor = true;
            this.butt2.Click += new System.EventHandler(this.butt2_Click);
            // 
            // lab_User
            // 
            this.lab_User.AutoSize = true;
            this.lab_User.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_User.Location = new System.Drawing.Point(590, 29);
            this.lab_User.Name = "lab_User";
            this.lab_User.Size = new System.Drawing.Size(36, 16);
            this.lab_User.TabIndex = 23;
            this.lab_User.Text = "User";
            // 
            // butt_lab_User
            // 
            this.butt_lab_User.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.butt_lab_User.Location = new System.Drawing.Point(569, 48);
            this.butt_lab_User.Name = "butt_lab_User";
            this.butt_lab_User.Size = new System.Drawing.Size(81, 44);
            this.butt_lab_User.TabIndex = 22;
            this.butt_lab_User.Text = "登出";
            this.butt_lab_User.UseVisualStyleBackColor = true;
            this.butt_lab_User.Click += new System.EventHandler(this.butt_lab_User_Click);
            // 
            // text_pass2
            // 
            this.text_pass2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.text_pass2.Location = new System.Drawing.Point(246, 255);
            this.text_pass2.Name = "text_pass2";
            this.text_pass2.PasswordChar = '*';
            this.text_pass2.Size = new System.Drawing.Size(236, 22);
            this.text_pass2.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(155, 261);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 16);
            this.label8.TabIndex = 19;
            this.label8.Text = "確認密碼";
            // 
            // text_down3
            // 
            this.text_down3.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.text_down3.Location = new System.Drawing.Point(114, 8);
            this.text_down3.Name = "text_down3";
            this.text_down3.PasswordChar = '*';
            this.text_down3.Size = new System.Drawing.Size(236, 22);
            this.text_down3.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(28, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 16);
            this.label9.TabIndex = 24;
            this.label9.Text = "更改密碼";
            // 
            // text_down4
            // 
            this.text_down4.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.text_down4.Location = new System.Drawing.Point(114, 61);
            this.text_down4.Name = "text_down4";
            this.text_down4.PasswordChar = '*';
            this.text_down4.Size = new System.Drawing.Size(236, 22);
            this.text_down4.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(28, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "確認密碼";
            // 
            // butt1
            // 
            this.butt1.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.butt1.Location = new System.Drawing.Point(65, 114);
            this.butt1.Name = "butt1";
            this.butt1.Size = new System.Drawing.Size(96, 57);
            this.butt1.TabIndex = 28;
            this.butt1.Text = "註銷";
            this.butt1.UseVisualStyleBackColor = true;
            this.butt1.Click += new System.EventHandler(this.butt1_Click);
            // 
            // lab11
            // 
            this.lab11.AutoSize = true;
            this.lab11.Location = new System.Drawing.Point(287, 306);
            this.lab11.Name = "lab11";
            this.lab11.Size = new System.Drawing.Size(0, 12);
            this.lab11.TabIndex = 21;
            // 
            // lab2
            // 
            this.lab2.AutoSize = true;
            this.lab2.Location = new System.Drawing.Point(155, 91);
            this.lab2.Name = "lab2";
            this.lab2.Size = new System.Drawing.Size(0, 12);
            this.lab2.TabIndex = 29;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lab2);
            this.panel1.Controls.Add(this.butt1);
            this.panel1.Controls.Add(this.text_down4);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.text_down3);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.butt3);
            this.panel1.Location = new System.Drawing.Point(119, 229);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(413, 192);
            this.panel1.TabIndex = 30;
            // 
            // lab1
            // 
            this.lab1.AutoSize = true;
            this.lab1.Location = new System.Drawing.Point(280, 211);
            this.lab1.Name = "lab1";
            this.lab1.Size = new System.Drawing.Size(0, 12);
            this.lab1.TabIndex = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 515);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox text_pass1;
        private System.Windows.Forms.TextBox text_user;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button butt_up;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.TextBox text_down1;
        private System.Windows.Forms.TextBox text_down2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button butt3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lab_User;
        private System.Windows.Forms.Button butt_lab_User;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button butt2;
        private System.Windows.Forms.TextBox text_pass2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button butt1;
        private System.Windows.Forms.TextBox text_down4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox text_down3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lab11;
        private System.Windows.Forms.Label lab2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lab1;
    }
}

