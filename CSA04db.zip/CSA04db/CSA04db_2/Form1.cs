﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CSA04db_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static Database db = new Database();
        static List<DateTime> list_date = new List<DateTime>();

        private void Form1_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now.AddDays(1);
            dateTimePicker2.MinDate = DateTime.Now.AddDays(2);
            dataGridView1.Visible = false;
            listBox1.Visible = true;
            up_list();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker2.MinDate = dateTimePicker1.Value.AddDays(1);
            dateTimePicker2.Value = dateTimePicker2.MinDate;
        }
        private bool Che_date(DateTime dt1, DateTime dt2)
        {
            foreach (var item in list_date)
            {
                if (item == dt1 || item == dt2)
                {
                    return false;
                }
            }
            return true;
        }
        private void add_date(DateTime dt1, DateTime dt2)
        {
            while (dt1 <= dt2)
            {
                list_date.Add(dt1);
                dt1 = dt1.AddDays(1);
            }
        }
        private void re_date(DateTime dt1, DateTime dt2)
        {
            while (dt1 <= dt2)
            {
                list_date.Remove(dt1);
                dt1 = dt1.AddDays(1);
            }
        }
        private void up_list()
        {
            if (radioButton3.Checked)
            {
                listBox1.Visible = true;
                dataGridView1.Visible = false;
                listBox1.Items.Clear();
                foreach (var item in db.Tables)
                {
                    if (DateTime.Parse(item.入住日期).Date < DateTime.Now)
                    {
                        db.Tables.Remove(item);
                    }
                    listBox1.Items.Add($"{item.入住日期}-{item.退房日期}-{item.人數} 房型：{item.房型} 付現：{item.付現} 金額：{item.金額}");
                }
            }
            if (radioButton4.Checked)
            {
                listBox1.Visible = false;
                dataGridView1.Visible = true;
                dataGridView1.Rows.Clear();
                foreach (var item in db.Tables)
                {
                    if (DateTime.Parse(item.入住日期).Date < DateTime.Now)
                    {
                        db.Tables.Remove(item);
                    }
                    dataGridView1.Rows.Add(item.入住日期, item.退房日期, item.人數, item.房型, item.付現, item.金額);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || comboBox2.Text == "")
            {
                MessageBox.Show("請輸入資料");
                return;
            }
            if (db.Tables.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日")) == null && Che_date(dateTimePicker1.Value.Date, dateTimePicker2.Value.Date))
            {
                //金額
                double money = 0;
                switch (comboBox2.Text)
                {
                    case "背包客房：每晚1200元":
                        money = 1200;
                        break;
                    case "普通房：每晚2000元":
                        money = 2000;
                        break;
                    case "豪華房：每晚3500元":
                        money = 3500;
                        break;
                    case "家庭房：每晚4800元":
                        money = 4800;
                        break;
                    case "總統套房：每晚15000元":
                        money = 15000;
                        break;
                }
                DateTime dt1 = dateTimePicker1.Value.Date;
                DateTime dt2 = dateTimePicker2.Value.Date;
                int days = Math.Abs((dt2 - dt1).Days); // 確保是正數
                money = money * days;
                if (days >= 5)
                {
                    money *= 0.85;
                }
                if (radioButton1.Checked)
                {
                    money *= 0.9;
                }
                if (dt1.DayOfWeek == 0)
                {
                    money *= 0.88;
                }
                DateTime week2 = new DateTime(dt1.Year, dt1.Month, 1);
                while (week2.DayOfWeek != 0)
                {
                    week2 = week2.AddDays(1); //重新賦值
                }
                if (dt1.Day >= week2.Day && dt1.Day <= week2.Day)
                {
                    money *= 0.95;
                }

                db.Tables.Add(new Table
                {
                    入住日期 = dateTimePicker1.Value.ToString("yyyy年MM月dd日"),
                    退房日期 = dateTimePicker2.Value.ToString("yyyy年MM月dd日"),
                    人數 = comboBox1.Text,
                    房型 = comboBox2.Text,
                    付現 = radioButton1.Checked ? "是" : "否",
                    金額 = money.ToString("C0")
                });
                db.SaveChanges();
                up_list();
                add_date(dateTimePicker1.Value.Date, dateTimePicker2.Value.Date);
                radioButton1.Checked = true;
                comboBox1.Text = comboBox2.Text = null;
                MessageBox.Show("訂房成功");
            }
            else
            {
                MessageBox.Show("已有資料");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var find_dt1 = db.Tables.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
            if (find_dt1 != null)
            {
                db.Tables.Remove(find_dt1);
                db.SaveChanges();
                re_date(DateTime.Parse(find_dt1.入住日期).Date, DateTime.Parse(find_dt1.退房日期).Date);
                up_list();
                radioButton1.Checked = true;
                comboBox1.Text = comboBox2.Text = null;
                MessageBox.Show("取消成功");
            }
            else
            {
                MessageBox.Show("查無資料");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            db.Tables.RemoveRange(db.Tables);
            db.SaveChanges();
            up_list();
            radioButton1.Checked = true;
            comboBox1.Text = comboBox2.Text = null;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var item = db.Tables.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
            if (item != null)
            {
                if (radioButton3.Checked)
                {
                    listBox1.Visible = true;
                    dataGridView1.Visible = false;
                    listBox1.Items.Clear();
                    listBox1.Items.Add($"{item.入住日期}-{item.退房日期}-{item.人數} 房型：{item.房型} 付現：{item.付現} 金額：{item.金額}");
                }
                if (radioButton4.Checked)
                {
                    listBox1.Visible = false;
                    dataGridView1.Visible = true;
                    dataGridView1.Rows.Clear();
                    dataGridView1.Rows.Add(item.入住日期, item.退房日期, item.人數, item.房型, item.付現, item.金額);
                }
            }
            else
            {
                MessageBox.Show("查無資料");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var item = db.Tables.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
            if (item != null)
            {
                //金額
                double money = 0;
                string room;
                if (comboBox2.Text != "")
                {
                    room = comboBox2.Text;
                }
                else
                {
                    room = item.房型;
                }
                switch (room)
                {
                    case "背包客房：每晚1200元":
                        money = 1200;
                        break;
                    case "普通房：每晚2000元":
                        money = 2000;
                        break;
                    case "豪華房：每晚3500元":
                        money = 3500;
                        break;
                    case "家庭房：每晚4800元":
                        money = 4800;
                        break;
                    case "總統套房：每晚15000元":
                        money = 15000;
                        break;
                }
                DateTime dt1 = DateTime.Parse(item.入住日期);
                DateTime dt2 = DateTime.Parse(item.退房日期);
                int days = Math.Abs((dt2 - dt1).Days); // 確保是正數
                money *= days;
                if (days >= 5)
                {
                    money *= 0.85;
                }
                if (radioButton1.Checked)
                {
                    money *= 0.9;
                }
                if (dt1.DayOfWeek == 0)
                {
                    money *= 0.88;
                }
                DateTime week2 = new DateTime(dt1.Year, dt1.Month, 1);
                while (week2.DayOfWeek != 0)
                {
                    week2 = week2.AddDays(1);
                }
                if (dt1.Day >= week2.Day && dt1.Day <= week2.Day)
                {
                    money *= 0.95;
                }

                if (comboBox1.Text != "")
                {
                    item.人數 = comboBox1.Text;
                }
                item.房型 = room;
                item.付現 = radioButton1.Checked ? "是" : "否";
                item.金額 = money.ToString("C0");

                db.SaveChanges();
                up_list();
                radioButton1.Checked = true;
                comboBox1.Text = comboBox2.Text = null;
                MessageBox.Show("修改成功");
            }
            else
            {
                MessageBox.Show("查無資料");
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            up_list();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            up_list();
        }
    }
}
