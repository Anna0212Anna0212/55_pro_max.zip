﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSA05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static Database1 db = new Database1();
        private void Form1_Load(object sender, EventArgs e)
        {
            db.Class1.RemoveRange(db.Class1);
            db.SaveChanges();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("請輸入資料");
                return;
            }
            if (!textBox2.Text.Any(char.IsLetterOrDigit) || !Regex.IsMatch(textBox2.Text, @"[^\s\w]") || textBox2.Text.Length < 8)
            {
                MessageBox.Show("密碼格式不正確");
                return;
            }
            if (db.Class1.Find(textBox1.Text) != null)
            {
                MessageBox.Show("帳號已存在");
                return;
            }
            else
            {
                what_sha(textBox2.Text, comboBox1.Text);
                db.Class1.Add(new Class1 { Id = textBox1.Text, Pass = sha });
                db.SaveChanges();
                textBox1.Text = null;
                textBox2.Text = null;
                comboBox1.Text = null;
                MessageBox.Show("註冊成功");
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            textBox4.PasswordChar = checkBox2.Checked ? '\0' : '*';
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }
        static string sha;
        private void what_sha(string pass, string com)
        {
            switch (com)
            {
                case "SHA1":
                    sha = BitConverter.ToString(SHA1.Create().ComputeHash(Encoding.UTF8.GetBytes(pass))).Replace("-","");
                    break;
                case "SHA256":
                    sha = BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(pass))).Replace("-", "");
                    break;
                case "SHA384":
                    sha = BitConverter.ToString(SHA384.Create().ComputeHash(Encoding.UTF8.GetBytes(pass))).Replace("-", "");
                    break;
                case "SHA512":
                    sha = BitConverter.ToString(SHA512.Create().ComputeHash(Encoding.UTF8.GetBytes(pass))).Replace("-", "");
                    break;
                case "MD5":
                    sha = BitConverter.ToString(MD5.Create().ComputeHash(Encoding.UTF8.GetBytes(pass))).Replace("-", "");
                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("請輸入資料");
                return;
            }
            var db_line = db.Class1.Find(textBox1.Text);
            if (db_line.Id == null)
            {
                MessageBox.Show("帳號不存在");
                return;
            }
            what_sha(textBox2.Text, comboBox1.Text);
            if (db_line.Id == textBox1.Text && db_line.Pass == sha)
            {
                db.Class1.Remove(db_line);
                db.SaveChanges();
                textBox1.Text = null;
                textBox2.Text = null;
                comboBox1.Text = null;
                MessageBox.Show("註銷成功");
            }
            else
            {
                MessageBox.Show("帳號或密碼錯誤");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "" || textBox4.Text == "" || comboBox2.Text == "")
            {
                MessageBox.Show("請輸入資料");
                return;
            }
            var db_line = db.Class1.Find(textBox3.Text);
            if (db_line.Id == null)
            {
                MessageBox.Show("帳號不存在");
                return;
            }
            what_sha(textBox4.Text, comboBox2.Text);
            if (db_line.Id == textBox3.Text && db_line.Pass == sha)
            {
                MessageBox.Show("歡迎" + textBox3.Text);
                textBox3.Text = null;
                textBox4.Text = null;
                comboBox2.Text = null;
            }
            else
            {
                MessageBox.Show("帳號或密碼錯誤");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox3.Text = null;
            textBox4.Text = null;
            comboBox2.Text = null;
        }
    }
}
