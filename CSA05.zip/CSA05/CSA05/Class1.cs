﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace CSA05
{
    public class Database1 : DbContext
    {
        public DbSet<Class1> Class1 { get; set; }
    }
    public partial class Class1
    {
        [Key]
        public string Id { get; set; }
        public string Pass { get; set; }
    }
}
