﻿using System;
using System.Windows.Forms;

namespace CSA04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static Database db = new Database();

        private void Form1_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now.AddDays(1);
            dateTimePicker2.MinDate = DateTime.Now.AddDays(2);
            listBox1.Visible = true;
            dataGridView1.Visible = false;
            up_date();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker2.MinDate = dateTimePicker1.Value.AddDays(1);
            dateTimePicker2.Value = dateTimePicker2.MinDate;
        }

        public void up_date()
        {
            if (radioButton3.Checked)
            {
                dataGridView1.Visible = false;
                listBox1.Visible = true;
                listBox1.Items.Clear();
                foreach (var item in db.Users)
                {
                    DateTime dt1 = DateTime.Parse(item.入住日期);
                    DateTime dt2 = DateTime.Parse(item.退房日期);
                    if (dt1.Date > DateTime.Now && dt2.Date > dt1.Date)
                    {
                        listBox1.Items.Add(item.入住日期 + "-" + item.退房日期 + "-" + item.人數 + " 房型：" + item.房型 + " 付現：" + item.現金);
                    }
                }
            }
            if (radioButton4.Checked)
            {
                listBox1.Visible = false;
                dataGridView1.Visible = true;
                dataGridView1.Rows.Clear();
                foreach (var item in db.Users)
                {
                    DateTime dt1 = DateTime.Parse(item.入住日期);
                    DateTime dt2 = DateTime.Parse(item.退房日期);
                    if (dt1.Date > DateTime.Now && dt2.Date > dt1.Date)
                    {
                        dataGridView1.Rows.Add(item.入住日期, item.退房日期, item.人數, item.房型, item.現金);
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日")) == null)
            {
                db.Users.Add(new User
                {
                    入住日期 = dateTimePicker1.Value.ToString("yyyy年MM月dd日"),
                    退房日期 = dateTimePicker2.Value.ToString("yyyy年MM月dd日"),
                    人數 = comboBox1.Text,
                    房型 = comboBox2.Text,
                    現金 = radioButton1.Checked ? "是" : "否"
                });
                db.SaveChanges();
                up_date();
                MessageBox.Show("訂房成功");
            }
            else
            {
                MessageBox.Show("已有人訂房");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日")) != null)
            {
                db.Users.Remove(db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日")));
                db.SaveChanges();
                up_date();
                MessageBox.Show("取消成功");
            }
            else
            {
                MessageBox.Show("無人訂房");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var db_line = db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
            if (db_line != null && button4.Text=="查詢")
            {
                listBox1.Items.Clear();
                listBox1.Items.Add(db_line.入住日期 + "-" + db_line.退房日期 + "-" + db_line.人數 + " 房型：" + db_line.房型 + " 付現：" + db_line.現金);
                button4.Text = "取消查詢";
                MessageBox.Show("查詢成功");
            }
            else if(button4.Text == "取消查詢")
            {
                up_date();
                button4.Text = "查詢";
                MessageBox.Show("資料重載完成");
            }
            else
            {
                up_date();
                MessageBox.Show("無人訂房");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var db_line = db.Users.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
            if (db_line != null)
            {
                if(comboBox1.Text != "")
                {
                    db_line.人數 = comboBox1.Text;
                }
                if (comboBox2.Text != "")
                {
                    db_line.房型 = comboBox2.Text;
                }
                if (radioButton1.Checked)
                {
                    db_line.現金 = "是";
                }
                else
                {
                    db_line.現金 = "否";
                }
                db.SaveChanges();
                up_date();
                MessageBox.Show("修改成功");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            db.Users.RemoveRange(db.Users);
            db.SaveChanges();
            up_date();
            MessageBox.Show("清空成功");
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            up_date();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            up_date();
        }
    }
}
