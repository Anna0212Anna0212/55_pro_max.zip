﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSA02
{
    class Program
    {
        static int[] num;
        static void Main(string[] args)
        {
            int value;
            while (true)
            {
                Console.Write("輸入數量(0-10)：");
                if (int.TryParse(Console.ReadLine(), out value) && value > 0 && value < 10)
                {
                    break;
                }
            }
            num = new int[value];
            for (int i = 0; i < num.Length; i++)
            {
                Console.Write("輸入第" + (i + 1) + "個數字(0-100)：");
                if (!int.TryParse(Console.ReadLine(), out num[i]) || num[i] <= 0 || num[i] > 100)
                {
                    i--;
                }
            }
            Console.Write("最大公因數：");
            for (int i = num.Min(); i > 0; i--)
            {
                bool ok_max = true;
                foreach (int j in num)
                {
                    if (j % i != 0)
                    {
                        ok_max = false;
                        break;
                    }
                }
                if (ok_max)
                {
                    Console.WriteLine(i);
                    break;
                }
            }
            Console.Write("最小公倍數：");
            for (int i = num.Max(); i > 0; i++)
            {
                bool ok_min = true;
                foreach (int j in num)
                {
                    if (i % j != 0)
                    {
                        ok_min = false;
                        break;
                    }
                }
                if (ok_min)
                {
                    Console.WriteLine(i);
                    break;
                }
            }
            Console.Write(value + "個數的公因數：");
            List<int> factors = new List<int>();
            for (int i = 1; i <= num.Min(); i++)
            {
                bool ok = true;
                foreach (int j in num)
                {
                    if (j % i != 0)
                    {
                        ok = false;
                        break;
                    }
                }
                if (ok)
                {
                    factors.Add(i);
                    Console.Write(i + " ");
                }
            }
            Console.WriteLine();
            foreach (int i in num)
            {
                Console.Write(i + "的因數：");
                for (int j = 1; j <= i; j++)
                {
                    if (factors.Any(x => x == j))
                        Console.ForegroundColor = ConsoleColor.Red;
                    if (i % j == 0)
                    {
                        Console.Write(j + " ");
                    }
                    Console.ResetColor();
                }
                Console.WriteLine();
            }
            Console.WriteLine(value + "個數的短除法公式：");
            while (Ok_num())
            {
                Console.Write(ans + " |");
                for (int i = 0; i < num.Length; i++)
                {
                    Console.Write(" " + num[i] + " ");
                    if (num[i] % ans == 0)
                    {
                        num[i] /= ans;
                    }
                }
                Console.WriteLine();
            }
            Console.Write("   | ");
            foreach (int i in num)
            {
                Console.Write($"{i} ");
            }
        }
        static int ans;
        static bool Ok_num()
        {
            for (int i = 2; i <= num.Min(); i++)
            {
                int k = 0;
                foreach (int j in num)
                {
                    if (j % i == 0)
                    {
                        k++;
                    }
                }
                if (k >= 2)
                {
                    ans = i;
                    return true;
                }
            }
            return false;
        }
    }
}
