﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSA03
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "選擇檔案";
            open.Filter = "文檔(*.txt)|*.txt|圖檔(*.jpg;*.png;*.bmp)|*.jpg;*.png;*.bmp";
            if(open.ShowDialog() == DialogResult.OK)
            {
                FileInfo fileInfo = new FileInfo(open.FileName);
                label3.Text = $"檔案名稱：{fileInfo.Name}\n檔案大小：{fileInfo.Length}bytes\n檔案建立時間：{fileInfo.CreationTime}\n檔案上次修改時間：{fileInfo.LastWriteTime}";
                
                panel3.Visible = true;
                string ex = Path.GetExtension(open.FileName);
                if(ex == ".txt")
                {
                    textBox1.Visible = panel1.Visible = true;
                    pictureBox1.Visible = panel2.Visible = false;
                    textBox1.Text = File.ReadAllText(open.FileName);
                }
                else if(ex == ".jpg"|| ex == ".png" || ex == ".bmp")
                {
                    textBox1.Visible = panel1.Visible = false;
                    pictureBox1.Visible = panel2.Visible = true;
                    pictureBox1.Image = Image.FromFile(open.FileName);
                }
                else
                {
                    MessageBox.Show("不支援檔案格式");
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Visible = pictureBox1.Visible = panel1.Visible = panel2.Visible = panel3.Visible = false;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            pictureBox1.Size = textBox1.Size = new Size(trackBar1.Value*10, trackBar1.Value*10);
            label2.Text = $"({trackBar1.Value * 10},{trackBar1.Value * 10})";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "儲存檔案";
            if (textBox1.Visible)
            {
                save.Filter = "文檔(*.txt)|*.txt";
            }
            else if(pictureBox1.Visible)
            {
                save.Filter = "圖檔(*.bmp)|*.bmp|圖檔(*.png)|*.png|圖檔(*.bmp)|*.bmp";
            }
            if(save.ShowDialog() == DialogResult.OK)
            {
                string ex = Path.GetExtension(save.FileName);
                save.DefaultExt = ex;
                if (ex == ".txt")
                {
                    if(radioButton2.Checked)
                        File.WriteAllText(save.FileName,textBox1.Text);
                    else if(radioButton1.Checked)
                        File.AppendAllText(save.FileName,textBox1.Text);
                }
                else if (ex == ".jpg" || ex == ".png" || ex == ".bmp")
                {
                    try
                    {
                        Bitmap bitmap = new Bitmap(pictureBox1.Image);
                        bitmap.Save(save.FileName);
                    }
                    catch
                    {
                        MessageBox.Show("error");
                    }
                }
                else
                {
                    MessageBox.Show("不支援檔案格式");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using(FontDialog font = new FontDialog())
            {
                if(font.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Font = font.Font;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using(ColorDialog color = new ColorDialog())
            {
                if(color.ShowDialog() == DialogResult.OK)
                {
                    textBox1.ForeColor = color.Color;
                }
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton3.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton7.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton6.Checked)
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboBox1.Text)
            {
                case "None":
                    textBox1.BorderStyle = BorderStyle.None; break;
                case "FixedSingle":
                    textBox1.BorderStyle = BorderStyle.FixedSingle; break;
                case "Fixed3D":
                    textBox1.BorderStyle = BorderStyle.Fixed3D; break;
            }
        }
    }
}
