﻿using System;
using System.Linq;

namespace CSA01
{
    class Program
    {
        static string card;
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("輸入信用卡號：");
                card = Console.ReadLine();
                if (card.Length == 16 && card.All(char.IsDigit))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("輸入錯誤");
                }
            }

            if (CheckCard(card))
            {
                Console.WriteLine("信用卡號合法");
            }
            else
            {
                Console.WriteLine("信用卡號非法");
                return;
            }

            Console.WriteLine("生成五個前兩碼相同合法信用卡號：");
            addCard(card.Substring(0, 2));

            where_card(card.Substring(0, 2));

            Console.WriteLine();
            if(ok_money)
            {
                Console.WriteLine("此卡片可在本店使用");
            }
            else
            {
                Console.WriteLine("此卡片不可在本店使用");
                return;
            }

            double money;
            while (true)
            {
                Console.Write("輸入金額：");
                if (double.TryParse(Console.ReadLine(), out money))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("輸入錯誤");
                }
            }
            string[] store = { "Casual Shopper：", "Premium Member：", "Elite VIP：", "Black Card Member：" };
            double[] ints = { 0.02, 0.08, 0.14, 0.2 };
            for(int i = 0; i < 4; i++)
            {
                Console.WriteLine(store[i] + (money * ints[i]).ToString("C1"));
            }
        }
        static bool ok_money;
        static void where_card(string card)
        {
            ok_money = true;
            switch (card)
            {
                case "03":
                    Console.Write("此卡片為聯合信用卡");
                    where2_card(int.Parse(card));
                    break;
                case "35":
                    Console.Write("此卡片為 JCB 信用卡");
                    where2_card(int.Parse(card));
                    break;
                case "45":
                    Console.Write("此卡片為 MASTER 信用卡");
                    where2_card(int.Parse(card));
                    break;
                case "54":
                    Console.Write("此卡片為 VISA 信用卡");
                    where2_card(int.Parse(card));
                    break;
                default:
                    Console.Write("非本店特約用戶");
                    ok_money = false;
                    where2_card(int.Parse(card));
                    break;
            }
        }
        static void where2_card(int card2)
        {
            switch (card2)
            {
                case int n when (n >= 30 && n <= 39):
                    Console.WriteLine("(大中華區)");
                    break;
                case int n when (n >= 30 && n <= 39):
                    Console.WriteLine("(歐美地區)");
                    break;
                default:
                    Console.WriteLine();
                    break;
            }
        }
        static bool CheckCard(string card)
        {
            int sum = 0;
            for (int i = 0; i < 16; i += 2)
            {
                int one = (card[i] - '0') * 2;
                sum += (one > 9 ? one - 9 : one) + (card[i + 1] - '0');
            }
            return sum % 10 == 0;
        }
        static Random random = new Random();
        static void addCard(string card2)
        {
            for (int i = 0; i < 5; i++)
            {
                string add_card;
                do
                {
                    add_card = card2;
                    while (add_card.Length != 16)
                    {
                        add_card += random.Next(0, 10);
                    }
                }
                while (CheckCard(add_card));
                Console.WriteLine(add_card);
            }
        }
    }
}
