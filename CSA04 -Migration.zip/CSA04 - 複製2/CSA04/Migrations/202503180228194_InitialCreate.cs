﻿namespace CSA04.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Tables",
                c => new
                    {
                        入住日期 = c.String(nullable: false, maxLength: 128),
                        退房日期 = c.String(),
                        人數 = c.String(),
                        房型 = c.String(),
                        付現 = c.String(),
                        金額 = c.String(),
                    })
                .PrimaryKey(t => t.入住日期);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Tables");
        }
    }
}
