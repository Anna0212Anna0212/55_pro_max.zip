﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CSA04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static Database db = new Database();
        static List<DateTime> list_dates = new List<DateTime>();

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (var item in db.tables)
            {
                DateTime in_dt = DateTime.Parse(item.入住日期).Date;
                DateTime out_dt = DateTime.Parse(item.退房日期).Date;
                if (in_dt < DateTime.Now.Date || out_dt <= in_dt)
                {
                    db.tables.Remove(item);
                }
            }
            db.SaveChanges();

            foreach (var item in db.tables)
            {
                DateTime in_dt = DateTime.Parse(item.入住日期).Date;
                DateTime out_dt = DateTime.Parse(item.退房日期).Date;

                while (in_dt <= out_dt)
                {
                    list_dates.Add(in_dt);
                    in_dt = in_dt.AddDays(1);
                }
            }

            dateTimePicker1.MinDate = DateTime.Now;
            dateTimePicker2.MinDate = DateTime.Now.AddDays(1);
            listBox1.Visible = true;
            dataGridView1.Visible = false;
            up_date();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker2.MinDate = dateTimePicker1.Value.AddDays(1);
            dateTimePicker2.Value = dateTimePicker2.MinDate;
        }

        static bool Che_date(DateTime dt1, DateTime dt2)
        {
            foreach (var item in list_dates)
            {
                if (dt1 == item || dt2 == item)
                {
                    return false;
                }
            }
            return true;
        }
        
        static void add_date(DateTime dt1, DateTime dt2)
        {
            while (dt1 != dt2)
            {
                list_dates.Add(dt1);
                dt1= dt1.AddDays(1);
            }
        }

        static void re_date(DateTime dt1, DateTime dt2)
        {
            while (dt1 != dt2)
            {
                list_dates.Remove(dt1);
                dt1 = dt1.AddDays(1);
            }
        }

        private void up_date()
        {
            if (radioButton3.Checked)
            {
                listBox1.Visible = true;
                dataGridView1.Visible =false;
                listBox1.Items.Clear();
                foreach(var item in db.tables)
                {
                    listBox1.Items.Add($"{item.入住日期}-{item.退房日期}-{item.人數} 房型：{item.房型} 付現：{item.付現} 金額：{item.金額}");
                }
            }
            else if (radioButton4.Checked)
            {
                listBox1.Visible = false;
                dataGridView1.Visible = true;
                dataGridView1.Rows.Clear();
                foreach (var item in db.tables)
                {
                    dataGridView1.Rows.Add(item.入住日期, item.退房日期, item.人數, item.房型, item.付現, item.金額);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime dt1 = dateTimePicker1.Value.Date;
            DateTime dt2 = dateTimePicker2.Value.Date;
            if (comboBox1.Text == "" || comboBox2.Text == "")
            {
                MessageBox.Show("輸入資料");
                return;
            }
            if (db.tables.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日")) != null || !Che_date(dt1, dt2))
            {
                MessageBox.Show("已有資料存在");
                return;
            }

            double money = 0;
            switch (comboBox2.Text)
            {
                case "背包客房：每晚1200元":
                    money = 1200; break;
                case "普通房：每晚2000元":
                    money = 2000; break;
                case "豪華房：每晚3500元":
                    money = 3500; break;
                case "家庭房：每晚4800元":
                    money = 4800; break;
                case "總統套房：每晚15000元":
                    money = 15000; break;
            }
            int day = Math.Abs((dt2 - dt1).Days);
            money = money * day;
            if (day >= 5)
            {
                money *= 0.85;
            }
            if (dt1.DayOfWeek == 0)
            {
                money *= 0.88;
            }
            DateTime week2 = new DateTime(dt1.Year, dt1.Month, 1);
            while (week2.DayOfWeek != 0)
            {
                week2 = week2.AddDays(1);
            }
            if (dt1 >= week2 && dt1 <= week2.AddDays(7))
            {
                money *= 0.95;
            }
            if (radioButton1.Checked)
            {
                money *= 0.9;
            }

            db.tables.Add(new Table
            {
                入住日期 = dateTimePicker1.Value.ToString("yyyy年MM月dd日"),
                退房日期 = dateTimePicker2.Value.ToString("yyyy年MM月dd日"),
                人數 = comboBox1.Text,
                房型 = comboBox2.Text,
                付現 = radioButton1.Checked ? "是" : "否",
                金額 = money.ToString("C0")
            });
            db.SaveChanges();
            add_date(dateTimePicker1.Value.Date,dateTimePicker2.Value.Date);
            up_date();
            comboBox1.Text = comboBox2.Text = null;
            radioButton1.Checked = true;
            MessageBox.Show("訂房成功");
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            up_date();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            up_date();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DateTime dt1 = dateTimePicker1.Value.Date;
            DateTime dt2 = dateTimePicker2.Value.Date;
            var item = db.tables.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
            if ( item == null)
            {
                MessageBox.Show("查無資料");
                return;
            }

            db.tables.Remove(item);
            db.SaveChanges();
            re_date(DateTime.Parse(item.入住日期), DateTime.Parse(item.退房日期));
            up_date();
            comboBox1.Text = comboBox2.Text = null;
            radioButton1.Checked = true;
            MessageBox.Show("退房成功");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            list_dates.Clear();
            db.tables.RemoveRange(db.tables);
            db.SaveChanges();
            up_date();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var item = db.tables.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
            if( item == null )
            {
                MessageBox.Show("查無資料");
                return;
            }
            if(button4.Text == "查詢")
            {
                if (radioButton3.Checked)
                {
                    listBox1.Visible = true;
                    dataGridView1.Visible = false;
                    listBox1.Items.Clear(); 
                    listBox1.Items.Add($"{item.入住日期}-{item.退房日期}-{item.人數} 房型：{item.房型} 付現：{item.付現} 金額：{item.金額}");
                }
                else if (radioButton4.Checked)
                {
                    listBox1.Visible = false;
                    dataGridView1.Visible = true;
                    dataGridView1.Rows.Clear();
                    dataGridView1.Rows.Add(item.入住日期, item.退房日期, item.人數, item.房型, item.付現, item.金額);
                }
                button4.Text = "取消查詢";
            }
            else if (button4.Text == "取消查詢")
            {
                button4.Text = "查詢";
                up_date();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var item = db.tables.Find(dateTimePicker1.Value.ToString("yyyy年MM月dd日"));
            if (item == null)
            {
                MessageBox.Show("查無資料");
                return;
            }

            if(comboBox1.Text != "")
            {
                item.人數 = comboBox1.Text;
            }
            if(comboBox2.Text != "")
            {
                item.房型 = comboBox2.Text;
            }

            DateTime dt1 = DateTime.Parse(item.入住日期);
            DateTime dt2 = DateTime.Parse(item.退房日期);

            double money = 0;
            switch (item.房型)
            {
                case "背包客房：每晚1200元":
                    money = 1200; break;
                case "普通房：每晚2000元":
                    money = 2000; break;
                case "豪華房：每晚3500元":
                    money = 3500; break;
                case "家庭房：每晚4800元":
                    money = 4800; break;
                case "總統套房：每晚15000元":
                    money = 15000; break;
            }
            int day = Math.Abs((dt2 - dt1).Days);
            money = money * day;
            if (day >= 5)
            {
                money *= 0.85;
            }
            if (dt1.DayOfWeek == 0)
            {
                money *= 0.88;
            }
            DateTime week2 = new DateTime(dt1.Year, dt1.Month, 1);
            while (week2.DayOfWeek != 0)
            {
                week2 = week2.AddDays(1);
            }
            if (dt1 >= week2 && dt1 <= week2.AddDays(7))
            {
                money *= 0.95;
            }
            if (radioButton1.Checked)
            {
                money *= 0.9;
            }

            item.付現 = radioButton1.Checked ? "是" : "否";
            item.金額 = money.ToString("C0");
            db.SaveChanges();
            up_date();
        }
    }
}
