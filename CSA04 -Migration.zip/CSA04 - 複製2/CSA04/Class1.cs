﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSA04
{
    public class Database:DbContext
    {
        public DbSet<Table>tables { get; set; }
    }
    public class Table
    {
        [Key]
        public string 入住日期 { get; set; }
        public string 退房日期 { get; set; }
        public string 人數 { get; set; }
        public string 房型 { get; set; }
        public string 付現 { get; set; }
        public string 金額 { get; set; }
    }
}
